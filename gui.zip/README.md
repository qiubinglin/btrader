# OrderFlowTrader - 订单流交易软件

基于Qt6和QML构建的现代化加密货币交易平台。

## 项目概述

OrderFlowTrader是一个专业的交易软件，提供实时行情数据、订单管理和交易执行功能。

### 主要特性

- 📊 实时行情数据 (Binance, OKEx)
- 📈 价格图表显示
- 📋 订单簿实时更新
- 💼 交易面板 (市价单/限价单)
- 📊 订单流分析
- 💰 账户管理
- 🎨 现代化UI界面

## 技术架构

- **C++17** - 核心业务逻辑
- **Qt6** - 跨平台GUI框架
- **QML** - 声明式UI设计
- **WebSocket** - 实时数据连接
- **CMake** - 构建系统

## 项目结构

```
OrderFlowTrader/
├── CMakeLists.txt              # 主构建文件
├── main.cpp                    # 应用程序入口
├── include/                    # 头文件
│   ├── market_data/           # 行情数据模块
│   ├── trading/               # 交易模块
│   ├── core/                  # 核心分析模块
│   └── ui/                    # UI控制模块
├── src/                       # 源代码
│   ├── market_data/           # 行情数据实现
│   ├── trading/               # 交易引擎实现
│   ├── core/                  # 核心分析实现
│   └── ui/                    # UI控制器实现
└── qml/                       # QML界面文件
    ├── main.qml              # 主界面
    └── components/           # UI组件
```

## 功能模块

### 1. 行情数据模块
- 实时行情数据获取
- 多交易所支持
- WebSocket连接管理

### 2. 交易引擎模块
- 订单管理
- 持仓管理
- 风险控制

### 3. 核心分析模块
- 订单流分析
- 风险管理
- 策略管理

### 4. UI控制模块
- 界面控制逻辑
- 数据绑定
- 用户交互处理

## 界面组件

1. **Market Data Panel** - 行情数据面板
2. **Trading Panel** - 交易面板
3. **Price Chart** - 价格图表
4. **Order Book** - 订单簿
5. **Order Flow** - 订单流
6. **Positions** - 持仓面板
7. **Orders** - 订单管理
8. **Account Info** - 账户信息

## 构建和运行

### 系统要求

- **操作系统**: Linux, Windows, macOS
- **编译器**: GCC 7.0+ 或 MSVC 2019+
- **Qt版本**: Qt 6.8.3+
- **CMake**: 3.16+

### 构建步骤

```bash
# 1. 创建构建目录
mkdir build && cd build

# 2. 配置CMake
cmake ..

# 3. 编译项目
make -j$(nproc)

# 4. 运行程序
./bin/OrderFlowTrader
```

### 依赖项

```bash
Qt6::Core
Qt6::Gui
Qt6::Widgets
Qt6::Quick
Qt6::QuickControls2
Qt6::Network
Qt6::WebSockets
```

## 配置说明

### 交易所配置

- **Binance**: `wss://stream.binance.com:9443/ws/`
- **OKEx**: `wss://ws.okx.com:8443/ws/v5/public`

### 模拟账户

- **账户ID**: SIMULATED_ACCOUNT
- **初始余额**: 100,000 USDT
- **支持交易对**: BTCUSDT, ETHUSDT, BNBUSDT等

## 开发指南

### 代码风格

- 遵循Google C++代码风格
- 使用驼峰命名法
- 类名使用PascalCase
- 函数和变量使用camelCase

### 添加新功能

1. **添加新的交易所支持**:
   - 继承`MarketDataProvider`类
   - 实现WebSocket连接
   - 在`MarketDataManager`中注册

2. **添加新的UI组件**:
   - 创建QML文件
   - 添加到`qml.qrc`资源文件
   - 在主界面中引用

## 故障排除

### 常见问题

1. **编译错误**:
   - 检查Qt6安装路径
   - 确认所有依赖项已安装

2. **运行时错误**:
   - 检查QML文件路径
   - 查看控制台错误信息

3. **连接问题**:
   - 检查网络连接
   - 确认交易所API状态

## 许可证

本项目采用MIT许可证。

## 注意事项

这是一个演示项目，仅供学习和研究使用。在实际交易中请谨慎使用，并遵守相关法律法规。 