#include "trading/trading_engine.h"
#include <QDebug>
#include <QUuid>
#include <QDateTime>

TradingEngine::TradingEngine(QObject *parent)
    : QObject(parent) {
  qDebug() << "TradingEngine initialized";
}

TradingEngine::~TradingEngine() {
  qDebug() << "TradingEngine destroyed";
}

QString TradingEngine::PlaceOrder(const QString &symbol, OrderType type,
                                 OrderSide side, double quantity, double price) {
  if (!ValidateOrder(symbol, type, side, quantity, price)) {
    qDebug() << "Invalid order parameters";
    return QString();
  }
  
  QString order_id = GenerateOrderId();
  
  Order order;
  order.order_id = order_id;
  order.symbol = symbol;
  order.type = type;
  order.side = side;
  order.price = price;
  order.quantity = quantity;
  order.filled_quantity = 0.0;
  order.remaining_quantity = quantity;
  order.status = OrderStatus::kPending;
  order.timestamp = QDateTime::currentMSecsSinceEpoch();
  order.exchange = "Simulated";
  order.client_order_id = order_id;
  order.message = "Order placed successfully";
  
  orders_[order_id] = order;
  
  // 模拟订单处理
  if (type == OrderType::kMarket) {
    // 市价单立即成交
    order.status = OrderStatus::kFilled;
    order.filled_quantity = quantity;
    order.remaining_quantity = 0.0;
    orders_[order_id] = order;
    
    // 创建成交记录
    Trade trade;
    trade.trade_id = GenerateTradeId();
    trade.order_id = order_id;
    trade.symbol = symbol;
    trade.side = side;
    trade.price = price > 0 ? price : 50000.0; // 模拟价格
    trade.quantity = quantity;
    trade.timestamp = QDateTime::currentMSecsSinceEpoch();
    trade.exchange = "Simulated";
    
    trades_.append(trade);
    
    emit OrderStatusChanged(order_id, OrderStatus::kFilled);
    emit OrderFilled(order_id, trade);
  } else {
    // 限价单等订单状态为已提交
    order.status = OrderStatus::kSubmitted;
    orders_[order_id] = order;
    emit OrderStatusChanged(order_id, OrderStatus::kSubmitted);
  }
  
  qDebug() << "Order placed:" << order_id << "for" << symbol;
  return order_id;
}

bool TradingEngine::CancelOrder(const QString &order_id) {
  if (!orders_.contains(order_id)) {
    qDebug() << "Order not found:" << order_id;
    return false;
  }
  
  Order &order = orders_[order_id];
  if (order.status == OrderStatus::kFilled || 
      order.status == OrderStatus::kCancelled) {
    qDebug() << "Cannot cancel order:" << order_id << "status:" 
             << static_cast<int>(order.status);
    return false;
  }
  
  order.status = OrderStatus::kCancelled;
  order.message = "Order cancelled by user";
  
  emit OrderStatusChanged(order_id, OrderStatus::kCancelled);
  qDebug() << "Order cancelled:" << order_id;
  return true;
}

bool TradingEngine::ModifyOrder(const QString &order_id, double new_price,
                               double new_quantity) {
  if (!orders_.contains(order_id)) {
    qDebug() << "Order not found:" << order_id;
    return false;
  }
  
  Order &order = orders_[order_id];
  if (order.status == OrderStatus::kFilled || 
      order.status == OrderStatus::kCancelled) {
    qDebug() << "Cannot modify order:" << order_id;
    return false;
  }
  
  order.price = new_price;
  order.quantity = new_quantity;
  order.remaining_quantity = new_quantity - order.filled_quantity;
  order.message = "Order modified";
  
  qDebug() << "Order modified:" << order_id;
  return true;
}

Order TradingEngine::GetOrder(const QString &order_id) const {
  return orders_.value(order_id, Order{});
}

QList<Order> TradingEngine::GetAllOrders() const {
  QList<Order> order_list;
  for (auto it = orders_.begin(); it != orders_.end(); ++it) {
    order_list.append(it.value());
  }
  return order_list;
}

QList<Order> TradingEngine::GetActiveOrders() const {
  QList<Order> active_orders;
  for (auto it = orders_.begin(); it != orders_.end(); ++it) {
    const Order &order = it.value();
    if (order.status == OrderStatus::kPending ||
        order.status == OrderStatus::kSubmitted ||
        order.status == OrderStatus::kPartiallyFilled) {
      active_orders.append(order);
    }
  }
  return active_orders;
}

QList<Trade> TradingEngine::GetTrades(const QString &symbol) const {
  if (symbol.isEmpty()) {
    return trades_;
  }
  
  QList<Trade> filtered_trades;
  for (const Trade &trade : trades_) {
    if (trade.symbol == symbol) {
      filtered_trades.append(trade);
    }
  }
  return filtered_trades;
}

Position TradingEngine::GetPosition(const QString &symbol) const {
  return positions_.value(symbol, Position{});
}

QMap<QString, Position> TradingEngine::GetAllPositions() const {
  return positions_;
}

Account TradingEngine::GetAccount() const {
  return account_;
}

void TradingEngine::UpdateOrderStatus(const QString &order_id, OrderStatus status) {
  if (orders_.contains(order_id)) {
    orders_[order_id].status = status;
    emit OrderStatusChanged(order_id, status);
  }
}

void TradingEngine::AddTrade(const Trade &trade) {
  trades_.append(trade);
}

void TradingEngine::UpdatePosition(const QString &symbol, const Position &position) {
  positions_[symbol] = position;
  emit PositionChanged(symbol, position);
}

void TradingEngine::UpdateAccount(const Account &account) {
  account_ = account;
  emit AccountUpdated(account);
}

QString TradingEngine::GenerateOrderId() const {
  return QUuid::createUuid().toString(QUuid::WithoutBraces);
}

QString TradingEngine::GenerateTradeId() const {
  return QUuid::createUuid().toString(QUuid::WithoutBraces);
}

bool TradingEngine::ValidateOrder(const QString &symbol, OrderType type,
                                 OrderSide side, double quantity, double price) const {
  if (symbol.isEmpty()) {
    qDebug() << "Symbol cannot be empty";
    return false;
  }
  
  if (quantity <= 0) {
    qDebug() << "Quantity must be positive";
    return false;
  }
  
  if (type == OrderType::kLimit && price <= 0) {
    qDebug() << "Limit order price must be positive";
    return false;
  }
  
  return true;
} 