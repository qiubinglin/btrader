#include "ui/main_window_controller.h"
#include "market_data/providers/binance_provider.h"
#include "market_data/providers/okex_provider.h"
#include <QDebug>

MainWindowController::MainWindowController(
    std::shared_ptr<MarketDataManager> market_data_manager,
    std::shared_ptr<TradingEngine> trading_engine,
    QObject *parent)
    : QObject(parent),
      market_data_manager_(market_data_manager),
      trading_engine_(trading_engine) {
  
  qDebug() << "MainWindowController initialized";
  
  // 初始化默认设置
  InitializeDefaultSettings();
  
  // 连接信号槽
  ConnectSignals();
}

MainWindowController::~MainWindowController() {
  DisconnectSignals();
  qDebug() << "MainWindowController destroyed";
}

std::shared_ptr<MarketDataManager> MainWindowController::GetMarketDataManager() const {
  return market_data_manager_;
}

std::shared_ptr<TradingEngine> MainWindowController::GetTradingEngine() const {
  return trading_engine_;
}

void MainWindowController::Initialize() {
  qDebug() << "Initializing application...";
  
  // 添加默认的行情数据提供者
  auto binance_provider = std::make_shared<BinanceProvider>();
  auto okex_provider = std::make_shared<OKExProvider>();
  
  market_data_manager_->AddProvider("Binance", binance_provider);
  market_data_manager_->AddProvider("OKEx", okex_provider);
  
  emit ApplicationInitialized();
  qDebug() << "Application initialized successfully";
}

void MainWindowController::Cleanup() {
  qDebug() << "Cleaning up application...";
  
  // 断开所有行情数据连接
  market_data_manager_->DisconnectProvider("Binance");
  market_data_manager_->DisconnectProvider("OKEx");
  
  qDebug() << "Application cleanup completed";
}

void MainWindowController::ConnectMarketData(const QString &provider_name) {
  market_data_manager_->ConnectProvider(provider_name);
}

void MainWindowController::DisconnectMarketData(const QString &provider_name) {
  market_data_manager_->DisconnectProvider(provider_name);
}

void MainWindowController::SubscribeSymbol(const QString &symbol,
                                         const QString &provider_name) {
  market_data_manager_->SubscribeMarketData(symbol, provider_name);
}

void MainWindowController::UnsubscribeSymbol(const QString &symbol,
                                           const QString &provider_name) {
  market_data_manager_->UnsubscribeMarketData(symbol, provider_name);
}

void MainWindowController::PlaceOrder(const QString &symbol, int order_type,
                                    int order_side, double quantity, double price) {
  OrderType type = static_cast<OrderType>(order_type);
  OrderSide side = static_cast<OrderSide>(order_side);
  
  QString order_id = trading_engine_->PlaceOrder(symbol, type, side, quantity, price);
  
  if (order_id.isEmpty()) {
    emit ErrorOccurred("Failed to place order");
  }
}

void MainWindowController::CancelOrder(const QString &order_id) {
  if (!trading_engine_->CancelOrder(order_id)) {
    emit ErrorOccurred("Failed to cancel order");
  }
}

void MainWindowController::ModifyOrder(const QString &order_id, double new_price,
                                     double new_quantity) {
  if (!trading_engine_->ModifyOrder(order_id, new_price, new_quantity)) {
    emit ErrorOccurred("Failed to modify order");
  }
}

void MainWindowController::OnMarketDataUpdated(const QString &symbol,
                                             const MarketData &data) {
  qDebug() << "Market data updated for" << symbol << "price:" << data.price;
}

void MainWindowController::OnOrderFlowDataUpdated(const QString &symbol,
                                                const OrderFlowData &data) {
  qDebug() << "Order flow data updated for" << symbol 
           << "side:" << data.side << "price:" << data.price;
}

void MainWindowController::OnOrderStatusChanged(const QString &order_id,
                                              OrderStatus status) {
  qDebug() << "Order status changed:" << order_id 
           << "status:" << static_cast<int>(status);
}

void MainWindowController::OnOrderFilled(const QString &order_id,
                                       const Trade &trade) {
  qDebug() << "Order filled:" << order_id 
           << "symbol:" << trade.symbol << "price:" << trade.price;
}

void MainWindowController::OnPositionChanged(const QString &symbol,
                                           const Position &position) {
  qDebug() << "Position changed for" << symbol 
           << "quantity:" << position.quantity;
}

void MainWindowController::OnAccountUpdated(const Account &account) {
  qDebug() << "Account updated, balance:" << account.balance;
}

void MainWindowController::ConnectSignals() {
  if (market_data_manager_) {
    connect(market_data_manager_.get(), &MarketDataManager::MarketDataUpdated,
            this, &MainWindowController::OnMarketDataUpdated);
    connect(market_data_manager_.get(), &MarketDataManager::OrderFlowDataUpdated,
            this, &MainWindowController::OnOrderFlowDataUpdated);
  }
  
  if (trading_engine_) {
    connect(trading_engine_.get(), &TradingEngine::OrderStatusChanged,
            this, &MainWindowController::OnOrderStatusChanged);
    connect(trading_engine_.get(), &TradingEngine::OrderFilled,
            this, &MainWindowController::OnOrderFilled);
    connect(trading_engine_.get(), &TradingEngine::PositionChanged,
            this, &MainWindowController::OnPositionChanged);
    connect(trading_engine_.get(), &TradingEngine::AccountUpdated,
            this, &MainWindowController::OnAccountUpdated);
  }
}

void MainWindowController::DisconnectSignals() {
  if (market_data_manager_) {
    disconnect(market_data_manager_.get(), nullptr, this, nullptr);
  }
  
  if (trading_engine_) {
    disconnect(trading_engine_.get(), nullptr, this, nullptr);
  }
}

void MainWindowController::InitializeDefaultSettings() {
  // 初始化默认的账户信息
  Account default_account;
  default_account.account_id = "SIMULATED_ACCOUNT";
  default_account.balance = 100000.0;
  default_account.equity = 100000.0;
  default_account.margin = 0.0;
  default_account.free_margin = 100000.0;
  default_account.margin_level = 0.0;
  default_account.currency = "USDT";
  default_account.exchange = "Simulated";
  
  trading_engine_->UpdateAccount(default_account);
} 