#include "market_data/market_data_manager.h"
#include "market_data/market_data_provider.h"
#include <QDebug>
#include <QUuid>

MarketDataManager::MarketDataManager(QObject *parent)
    : QObject(parent) {
  qDebug() << "MarketDataManager initialized";
}

MarketDataManager::~MarketDataManager() {
  // 断开所有提供者
  for (auto it = providers_.begin(); it != providers_.end(); ++it) {
    it.value()->Disconnect();
  }
  providers_.clear();
}

void MarketDataManager::AddProvider(const QString &name,
                                   std::shared_ptr<MarketDataProvider> provider) {
  if (provider) {
    providers_[name] = provider;
    
    // 连接信号
    connect(provider.get(), &MarketDataProvider::MarketDataUpdated,
            this, &MarketDataManager::OnMarketDataUpdated);
    connect(provider.get(), &MarketDataProvider::OrderFlowDataUpdated,
            this, &MarketDataManager::OnOrderFlowDataUpdated);
    // 使用lambda来处理ConnectionStatusChanged信号，添加provider_name参数
    connect(provider.get(), &MarketDataProvider::ConnectionStatusChanged,
            [this, name](bool connected) {
                emit ConnectionStatusChanged(name, connected);
            });
    
    qDebug() << "Added market data provider:" << name;
  }
}

void MarketDataManager::RemoveProvider(const QString &name) {
  if (providers_.contains(name)) {
    auto provider = providers_[name];
    if (provider) {
      provider->Disconnect();
    }
    providers_.remove(name);
    qDebug() << "Removed market data provider:" << name;
  }
}

void MarketDataManager::SubscribeMarketData(const QString &symbol,
                                           const QString &provider_name) {
  if (providers_.contains(provider_name)) {
    auto provider = providers_[provider_name];
    if (provider && provider->IsConnected()) {
      if (provider->SubscribeMarketData(symbol)) {
        qDebug() << "Subscribed to market data for" << symbol 
                 << "from" << provider_name;
      } else {
        qDebug() << "Failed to subscribe to market data for" << symbol 
                 << "from" << provider_name;
      }
    } else {
      qDebug() << "Provider" << provider_name << "is not connected";
    }
  } else {
    qDebug() << "Provider" << provider_name << "not found";
  }
}

void MarketDataManager::UnsubscribeMarketData(const QString &symbol,
                                             const QString &provider_name) {
  if (providers_.contains(provider_name)) {
    auto provider = providers_[provider_name];
    if (provider) {
      provider->UnsubscribeMarketData(symbol);
      qDebug() << "Unsubscribed from market data for" << symbol 
               << "from" << provider_name;
    }
  }
}

MarketData MarketDataManager::GetMarketData(const QString &symbol) const {
  return market_data_cache_.value(symbol, MarketData{});
}

QMap<QString, MarketData> MarketDataManager::GetAllMarketData() const {
  return market_data_cache_;
}

void MarketDataManager::ConnectProvider(const QString &provider_name) {
  if (providers_.contains(provider_name)) {
    auto provider = providers_[provider_name];
    if (provider) {
      if (provider->Connect()) {
        qDebug() << "Connected to provider:" << provider_name;
      } else {
        qDebug() << "Failed to connect to provider:" << provider_name;
      }
    }
  } else {
    qDebug() << "Provider" << provider_name << "not found";
  }
}

void MarketDataManager::DisconnectProvider(const QString &provider_name) {
  if (providers_.contains(provider_name)) {
    auto provider = providers_[provider_name];
    if (provider) {
      provider->Disconnect();
      qDebug() << "Disconnected from provider:" << provider_name;
    }
  }
}

void MarketDataManager::OnMarketDataUpdated(const QString &symbol,
                                           const MarketData &data) {
  market_data_cache_[symbol] = data;
  emit MarketDataUpdated(symbol, data);
}

void MarketDataManager::OnOrderFlowDataUpdated(const QString &symbol,
                                              const OrderFlowData &data) {
  if (!order_flow_cache_.contains(symbol)) {
    order_flow_cache_[symbol] = std::vector<OrderFlowData>();
  }
  
  order_flow_cache_[symbol].push_back(data);
  
  // 保持最近1000条订单流数据
  if (order_flow_cache_[symbol].size() > 1000) {
    order_flow_cache_[symbol].erase(
        order_flow_cache_[symbol].begin(),
        order_flow_cache_[symbol].begin() + 
        (order_flow_cache_[symbol].size() - 1000));
  }
  
  emit OrderFlowDataUpdated(symbol, data);
} 