#include "market_data/providers/binance_provider.h"
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

BinanceProvider::BinanceProvider(QObject *parent)
    : MarketDataProvider(parent),
      websocket_(nullptr),
      network_manager_(nullptr),
      ping_timer_(nullptr),
      is_connected_(false) {
  
  // 创建WebSocket
  websocket_ = new QWebSocket();
  
  // 创建网络管理器
  network_manager_ = new QNetworkAccessManager(this);
  
  // 创建ping定时器
  ping_timer_ = new QTimer(this);
  ping_timer_->setInterval(30000); // 30秒ping一次
  
  // 连接信号槽
  connect(websocket_, &QWebSocket::connected,
          this, &BinanceProvider::OnWebSocketConnected);
  connect(websocket_, &QWebSocket::disconnected,
          this, &BinanceProvider::OnWebSocketDisconnected);
  connect(websocket_, QOverload<QAbstractSocket::SocketError>::of(&QWebSocket::error),
          this, &BinanceProvider::OnWebSocketError);
  connect(websocket_, &QWebSocket::textMessageReceived,
          this, &BinanceProvider::OnWebSocketTextMessageReceived);
  connect(ping_timer_, &QTimer::timeout,
          this, &BinanceProvider::OnPingTimerTimeout);
  
  qDebug() << "BinanceProvider initialized";
}

BinanceProvider::~BinanceProvider() {
  Disconnect();
  if (websocket_) {
    websocket_->deleteLater();
  }
  if (ping_timer_) {
    ping_timer_->stop();
  }
}

bool BinanceProvider::Connect() {
  if (is_connected_) {
    qDebug() << "Already connected to Binance";
    return true;
  }
  
  qDebug() << "Connecting to Binance WebSocket...";
  websocket_->open(QUrl(kWebSocketUrl));
  return true;
}

void BinanceProvider::Disconnect() {
  if (!is_connected_) {
    return;
  }
  
  qDebug() << "Disconnecting from Binance...";
  ping_timer_->stop();
  websocket_->close();
  is_connected_ = false;
  subscribed_symbols_.clear();
  emit ConnectionStatusChanged(false);
}

bool BinanceProvider::IsConnected() const {
  return is_connected_;
}

bool BinanceProvider::SubscribeMarketData(const QString &symbol) {
  if (!is_connected_) {
    qDebug() << "Not connected to Binance";
    return false;
  }
  
  QString stream_name = symbol.toLower() + "@ticker";
  SendSubscribeMessage(stream_name);
  subscribed_symbols_.append(symbol);
  qDebug() << "Subscribed to market data for" << symbol;
  return true;
}

bool BinanceProvider::UnsubscribeMarketData(const QString &symbol) {
  if (!is_connected_) {
    return false;
  }
  
  QString stream_name = symbol.toLower() + "@ticker";
  SendUnsubscribeMessage(stream_name);
  subscribed_symbols_.removeAll(symbol);
  qDebug() << "Unsubscribed from market data for" << symbol;
  return true;
}

bool BinanceProvider::SubscribeOrderFlowData(const QString &symbol) {
  if (!is_connected_) {
    qDebug() << "Not connected to Binance";
    return false;
  }
  
  QString stream_name = symbol.toLower() + "@trade";
  SendSubscribeMessage(stream_name);
  qDebug() << "Subscribed to order flow data for" << symbol;
  return true;
}

bool BinanceProvider::UnsubscribeOrderFlowData(const QString &symbol) {
  if (!is_connected_) {
    return false;
  }
  
  QString stream_name = symbol.toLower() + "@trade";
  SendUnsubscribeMessage(stream_name);
  qDebug() << "Unsubscribed from order flow data for" << symbol;
  return true;
}

QStringList BinanceProvider::GetSupportedSymbols() const {
  // 返回一些常用的交易对
  return {"BTCUSDT", "ETHUSDT", "BNBUSDT", "ADAUSDT", "DOTUSDT",
          "LINKUSDT", "LTCUSDT", "BCHUSDT", "XRPUSDT", "EOSUSDT"};
}

void BinanceProvider::OnWebSocketConnected() {
  qDebug() << "Connected to Binance WebSocket";
  is_connected_ = true;
  ping_timer_->start();
  emit ConnectionStatusChanged(true);
}

void BinanceProvider::OnWebSocketDisconnected() {
  qDebug() << "Disconnected from Binance WebSocket";
  is_connected_ = false;
  ping_timer_->stop();
  emit ConnectionStatusChanged(false);
}

void BinanceProvider::OnWebSocketError(QAbstractSocket::SocketError error) {
  qDebug() << "WebSocket error:" << error;
  is_connected_ = false;
  ping_timer_->stop();
  emit ConnectionStatusChanged(false);
}

void BinanceProvider::OnWebSocketTextMessageReceived(const QString &message) {
  QJsonObject json_obj = ParseJsonMessage(message);
  if (json_obj.isEmpty()) {
    return;
  }
  
  if (ValidateMessage(json_obj)) {
    if (json_obj.contains("e") && json_obj["e"].toString() == "24hrTicker") {
      HandleTickerMessage(json_obj);
    } else if (json_obj.contains("e") && json_obj["e"].toString() == "trade") {
      HandleTradeMessage(json_obj);
    }
  }
}

void BinanceProvider::OnPingTimerTimeout() {
  SendPing();
}

void BinanceProvider::HandleTickerMessage(const QJsonObject &message) {
  MarketData data;
  data.symbol = message["s"].toString();
  data.price = message["c"].toString().toDouble();
  data.volume = message["v"].toString().toDouble();
  data.bid_price = message["b"].toString().toDouble();
  data.ask_price = message["a"].toString().toDouble();
  data.bid_volume = message["B"].toString().toDouble();
  data.ask_volume = message["A"].toString().toDouble();
  data.timestamp = message["E"].toVariant().toLongLong();
  data.exchange = "Binance";
  
  NotifyMarketDataUpdated(data.symbol, data);
}

void BinanceProvider::HandleTradeMessage(const QJsonObject &message) {
  OrderFlowData data;
  data.symbol = message["s"].toString();
  data.price = message["p"].toString().toDouble();
  data.volume = message["q"].toString().toDouble();
  data.side = message["m"].toBool() ? "sell" : "buy";
  data.order_type = "market";
  data.timestamp = message["T"].toVariant().toLongLong();
  data.exchange = "Binance";
  
  NotifyOrderFlowDataUpdated(data.symbol, data);
}

void BinanceProvider::SendSubscribeMessage(const QString &stream_name) {
  QJsonObject subscribe_msg;
  subscribe_msg["method"] = "SUBSCRIBE";
  subscribe_msg["params"] = QJsonArray{stream_name};
  subscribe_msg["id"] = 1;
  
  QJsonDocument doc(subscribe_msg);
  websocket_->sendTextMessage(doc.toJson());
}

void BinanceProvider::SendUnsubscribeMessage(const QString &stream_name) {
  QJsonObject unsubscribe_msg;
  unsubscribe_msg["method"] = "UNSUBSCRIBE";
  unsubscribe_msg["params"] = QJsonArray{stream_name};
  unsubscribe_msg["id"] = 2;
  
  QJsonDocument doc(unsubscribe_msg);
  websocket_->sendTextMessage(doc.toJson());
}

void BinanceProvider::SendPing() {
  QJsonObject ping_msg;
  ping_msg["method"] = "ping";
  ping_msg["id"] = 3;
  
  QJsonDocument doc(ping_msg);
  websocket_->sendTextMessage(doc.toJson());
}

QJsonObject BinanceProvider::ParseJsonMessage(const QString &message) {
  QJsonParseError error;
  QJsonDocument doc = QJsonDocument::fromJson(message.toUtf8(), &error);
  
  if (error.error != QJsonParseError::NoError) {
    qDebug() << "JSON parse error:" << error.errorString();
    return QJsonObject();
  }
  
  return doc.object();
}

bool BinanceProvider::ValidateMessage(const QJsonObject &message) {
  return !message.isEmpty();
} 