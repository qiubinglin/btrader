#include "market_data/providers/okex_provider.h"
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

OKExProvider::OKExProvider(QObject *parent)
    : MarketDataProvider(parent),
      websocket_(nullptr),
      network_manager_(nullptr),
      ping_timer_(nullptr),
      is_connected_(false) {
  
  // 创建WebSocket
  websocket_ = new QWebSocket();
  
  // 创建网络管理器
  network_manager_ = new QNetworkAccessManager(this);
  
  // 创建ping定时器
  ping_timer_ = new QTimer(this);
  ping_timer_->setInterval(30000); // 30秒ping一次
  
  // 连接信号槽
  connect(websocket_, &QWebSocket::connected,
          this, &OKExProvider::OnWebSocketConnected);
  connect(websocket_, &QWebSocket::disconnected,
          this, &OKExProvider::OnWebSocketDisconnected);
  connect(websocket_, QOverload<QAbstractSocket::SocketError>::of(&QWebSocket::error),
          this, &OKExProvider::OnWebSocketError);
  connect(websocket_, &QWebSocket::textMessageReceived,
          this, &OKExProvider::OnWebSocketTextMessageReceived);
  connect(ping_timer_, &QTimer::timeout,
          this, &OKExProvider::OnPingTimerTimeout);
  
  qDebug() << "OKExProvider initialized";
}

OKExProvider::~OKExProvider() {
  Disconnect();
  if (websocket_) {
    websocket_->deleteLater();
  }
  if (ping_timer_) {
    ping_timer_->stop();
  }
}

bool OKExProvider::Connect() {
  if (is_connected_) {
    qDebug() << "Already connected to OKEx";
    return true;
  }
  
  qDebug() << "Connecting to OKEx WebSocket...";
  websocket_->open(QUrl(kWebSocketUrl));
  return true;
}

void OKExProvider::Disconnect() {
  if (!is_connected_) {
    return;
  }
  
  qDebug() << "Disconnecting from OKEx...";
  ping_timer_->stop();
  websocket_->close();
  is_connected_ = false;
  subscribed_symbols_.clear();
  emit ConnectionStatusChanged(false);
}

bool OKExProvider::IsConnected() const {
  return is_connected_;
}

bool OKExProvider::SubscribeMarketData(const QString &symbol) {
  if (!is_connected_) {
    qDebug() << "Not connected to OKEx";
    return false;
  }
  
  SendSubscribeMessage("tickers", symbol);
  subscribed_symbols_.append(symbol);
  qDebug() << "Subscribed to market data for" << symbol;
  return true;
}

bool OKExProvider::UnsubscribeMarketData(const QString &symbol) {
  if (!is_connected_) {
    return false;
  }
  
  SendUnsubscribeMessage("tickers", symbol);
  subscribed_symbols_.removeAll(symbol);
  qDebug() << "Unsubscribed from market data for" << symbol;
  return true;
}

bool OKExProvider::SubscribeOrderFlowData(const QString &symbol) {
  if (!is_connected_) {
    qDebug() << "Not connected to OKEx";
    return false;
  }
  
  SendSubscribeMessage("trades", symbol);
  qDebug() << "Subscribed to order flow data for" << symbol;
  return true;
}

bool OKExProvider::UnsubscribeOrderFlowData(const QString &symbol) {
  if (!is_connected_) {
    return false;
  }
  
  SendUnsubscribeMessage("trades", symbol);
  qDebug() << "Unsubscribed from order flow data for" << symbol;
  return true;
}

QStringList OKExProvider::GetSupportedSymbols() const {
  // 返回一些常用的交易对
  return {"BTC-USDT", "ETH-USDT", "OKB-USDT", "ADA-USDT", "DOT-USDT",
          "LINK-USDT", "LTC-USDT", "BCH-USDT", "XRP-USDT", "EOS-USDT"};
}

void OKExProvider::OnWebSocketConnected() {
  qDebug() << "Connected to OKEx WebSocket";
  is_connected_ = true;
  ping_timer_->start();
  emit ConnectionStatusChanged(true);
}

void OKExProvider::OnWebSocketDisconnected() {
  qDebug() << "Disconnected from OKEx WebSocket";
  is_connected_ = false;
  ping_timer_->stop();
  emit ConnectionStatusChanged(false);
}

void OKExProvider::OnWebSocketError(QAbstractSocket::SocketError error) {
  qDebug() << "WebSocket error:" << error;
  is_connected_ = false;
  ping_timer_->stop();
  emit ConnectionStatusChanged(false);
}

void OKExProvider::OnWebSocketTextMessageReceived(const QString &message) {
  QJsonObject json_obj = ParseJsonMessage(message);
  if (json_obj.isEmpty()) {
    return;
  }
  
  if (ValidateMessage(json_obj)) {
    if (json_obj.contains("event")) {
      // 处理事件消息
      return;
    }
    
    if (json_obj.contains("arg")) {
      QJsonObject arg = json_obj["arg"].toObject();
      QString channel = arg["channel"].toString();
      
      if (channel == "tickers") {
        HandleTickerMessage(json_obj);
      } else if (channel == "trades") {
        HandleTradeMessage(json_obj);
      }
    }
  }
}

void OKExProvider::OnPingTimerTimeout() {
  SendPing();
}

void OKExProvider::HandleTickerMessage(const QJsonObject &message) {
  if (!message.contains("data")) {
    return;
  }
  
  QJsonArray data_array = message["data"].toArray();
  if (data_array.isEmpty()) {
    return;
  }
  
  QJsonObject ticker_data = data_array[0].toObject();
  
  MarketData data;
  data.symbol = ticker_data["instId"].toString();
  data.price = ticker_data["last"].toString().toDouble();
  data.volume = ticker_data["vol24h"].toString().toDouble();
  data.bid_price = ticker_data["bidPx"].toString().toDouble();
  data.ask_price = ticker_data["askPx"].toString().toDouble();
  data.bid_volume = ticker_data["bidSz"].toString().toDouble();
  data.ask_volume = ticker_data["askSz"].toString().toDouble();
  data.timestamp = ticker_data["ts"].toString().toLongLong();
  data.exchange = "OKEx";
  
  NotifyMarketDataUpdated(data.symbol, data);
}

void OKExProvider::HandleTradeMessage(const QJsonObject &message) {
  if (!message.contains("data")) {
    return;
  }
  
  QJsonArray data_array = message["data"].toArray();
  if (data_array.isEmpty()) {
    return;
  }
  
  QJsonObject trade_data = data_array[0].toObject();
  
  OrderFlowData data;
  data.symbol = trade_data["instId"].toString();
  data.price = trade_data["px"].toString().toDouble();
  data.volume = trade_data["sz"].toString().toDouble();
  data.side = trade_data["side"].toString();
  data.order_type = "market";
  data.timestamp = trade_data["ts"].toString().toLongLong();
  data.exchange = "OKEx";
  
  NotifyOrderFlowDataUpdated(data.symbol, data);
}

void OKExProvider::SendSubscribeMessage(const QString &channel, const QString &inst_id) {
  QJsonObject subscribe_msg;
  subscribe_msg["op"] = "subscribe";
  
  QJsonArray args;
  QJsonObject arg;
  arg["channel"] = channel;
  arg["instId"] = inst_id;
  args.append(arg);
  subscribe_msg["args"] = args;
  
  QJsonDocument doc(subscribe_msg);
  websocket_->sendTextMessage(doc.toJson());
}

void OKExProvider::SendUnsubscribeMessage(const QString &channel, const QString &inst_id) {
  QJsonObject unsubscribe_msg;
  unsubscribe_msg["op"] = "unsubscribe";
  
  QJsonArray args;
  QJsonObject arg;
  arg["channel"] = channel;
  arg["instId"] = inst_id;
  args.append(arg);
  unsubscribe_msg["args"] = args;
  
  QJsonDocument doc(unsubscribe_msg);
  websocket_->sendTextMessage(doc.toJson());
}

void OKExProvider::SendPing() {
  QJsonObject ping_msg;
  ping_msg["op"] = "ping";
  
  QJsonDocument doc(ping_msg);
  websocket_->sendTextMessage(doc.toJson());
}

QJsonObject OKExProvider::ParseJsonMessage(const QString &message) {
  QJsonParseError error;
  QJsonDocument doc = QJsonDocument::fromJson(message.toUtf8(), &error);
  
  if (error.error != QJsonParseError::NoError) {
    qDebug() << "JSON parse error:" << error.errorString();
    return QJsonObject();
  }
  
  return doc.object();
}

bool OKExProvider::ValidateMessage(const QJsonObject &message) {
  return !message.isEmpty();
} 