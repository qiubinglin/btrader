#include "market_data/market_data_provider.h"
#include <QDebug>

MarketDataProvider::MarketDataProvider(QObject *parent)
    : QObject(parent) {
  qDebug() << "MarketDataProvider base class initialized";
}

void MarketDataProvider::SetMarketDataCallback(
    std::function<void(const QString &, const MarketData &)> callback) {
  market_data_callback_ = callback;
}

void MarketDataProvider::SetOrderFlowDataCallback(
    std::function<void(const QString &, const OrderFlowData &)> callback) {
  order_flow_callback_ = callback;
}

void MarketDataProvider::NotifyMarketDataUpdated(const QString &symbol,
                                                const MarketData &data) {
  if (market_data_callback_) {
    market_data_callback_(symbol, data);
  }
  emit MarketDataUpdated(symbol, data);
}

void MarketDataProvider::NotifyOrderFlowDataUpdated(const QString &symbol,
                                                   const OrderFlowData &data) {
  if (order_flow_callback_) {
    order_flow_callback_(symbol, data);
  }
  emit OrderFlowDataUpdated(symbol, data);
} 