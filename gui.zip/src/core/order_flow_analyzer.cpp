#include "core/order_flow_analyzer.h"
#include <QDebug>

OrderFlowAnalyzer::OrderFlowAnalyzer(QObject *parent)
    : QObject(parent) {
  qDebug() << "OrderFlowAnalyzer initialized";
}

OrderFlowAnalyzer::~OrderFlowAnalyzer() {
  qDebug() << "OrderFlowAnalyzer destroyed";
}

void OrderFlowAnalyzer::AnalyzeOrderFlow(const QString &symbol, 
                                        const OrderFlowData &data) {
  // 简单的订单流分析逻辑
  qDebug() << "Analyzing order flow for" << symbol 
           << "side:" << data.side << "price:" << data.price;
} 