#include "core/strategy_manager.h"
#include <QDebug>

StrategyManager::StrategyManager(QObject *parent)
    : QObject(parent) {
  qDebug() << "StrategyManager initialized";
}

StrategyManager::~StrategyManager() {
  qDebug() << "StrategyManager destroyed";
}

void StrategyManager::ExecuteStrategy(const QString &strategy_name, 
                                    const QString &symbol) {
  // 简单的策略执行逻辑
  qDebug() << "Executing strategy" << strategy_name << "for" << symbol;
} 