#ifndef ORDER_FLOW_ANALYZER_H
#define ORDER_FLOW_ANALYZER_H

#include <QObject>
#include <QString>
#include "market_data/market_data_manager.h"

class OrderFlowAnalyzer : public QObject {
  Q_OBJECT

 public:
  explicit OrderFlowAnalyzer(QObject *parent = nullptr);
  ~OrderFlowAnalyzer();

  void AnalyzeOrderFlow(const QString &symbol, const OrderFlowData &data);

 signals:
  void AnalysisCompleted(const QString &symbol, const QString &result);

 private:
  // 分析逻辑实现
};

#endif  // ORDER_FLOW_ANALYZER_H 