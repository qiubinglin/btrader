#ifndef STRATEGY_MANAGER_H
#define STRATEGY_MANAGER_H

#include <QObject>
#include <QString>

class StrategyManager : public QObject {
  Q_OBJECT

 public:
  explicit StrategyManager(QObject *parent = nullptr);
  ~StrategyManager();

  void ExecuteStrategy(const QString &strategy_name, const QString &symbol);

 signals:
  void StrategyExecuted(const QString &strategy_name, const QString &result);

 private:
  // 策略执行逻辑实现
};

#endif  // STRATEGY_MANAGER_H 