#ifndef RISK_MANAGER_H
#define RISK_MANAGER_H

#include <QObject>
#include <QString>

class RiskManager : public QObject {
  Q_OBJECT

 public:
  explicit RiskManager(QObject *parent = nullptr);
  ~RiskManager();

  bool CheckOrderRisk(const QString &symbol, double quantity, double price);

 signals:
  void RiskAlert(const QString &message);

 private:
  // 风险控制逻辑实现
};

#endif  // RISK_MANAGER_H 