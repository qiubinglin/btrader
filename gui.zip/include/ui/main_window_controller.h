#ifndef MAIN_WINDOW_CONTROLLER_H
#define MAIN_WINDOW_CONTROLLER_H

#include <QObject>
#include <QString>
#include <memory>

#include "market_data/market_data_manager.h"
#include "trading/trading_engine.h"

class MainWindowController : public QObject {
  Q_OBJECT

 public:
  MainWindowController(std::shared_ptr<MarketDataManager> market_data_manager,
                      std::shared_ptr<TradingEngine> trading_engine,
                      QObject *parent = nullptr);
  ~MainWindowController();

  // 获取行情数据管理器
  std::shared_ptr<MarketDataManager> GetMarketDataManager() const;
  
  // 获取交易引擎
  std::shared_ptr<TradingEngine> GetTradingEngine() const;
  
  // 初始化应用程序
  void Initialize();
  
  // 清理资源
  void Cleanup();

 signals:
  // 应用程序初始化完成信号
  void ApplicationInitialized();
  
  // 错误信号
  void ErrorOccurred(const QString &error_message);

 public slots:
  // 连接行情数据源
  void ConnectMarketData(const QString &provider_name);
  
  // 断开行情数据源
  void DisconnectMarketData(const QString &provider_name);
  
  // 订阅行情数据
  void SubscribeSymbol(const QString &symbol, const QString &provider_name);
  
  // 取消订阅行情数据
  void UnsubscribeSymbol(const QString &symbol, const QString &provider_name);
  
  // 下单
  void PlaceOrder(const QString &symbol, int order_type, int order_side,
                  double quantity, double price = 0.0);
  
  // 取消订单
  void CancelOrder(const QString &order_id);
  
  // 修改订单
  void ModifyOrder(const QString &order_id, double new_price, double new_quantity);

 private slots:
  // 处理行情数据更新
  void OnMarketDataUpdated(const QString &symbol, const MarketData &data);
  
  // 处理订单流数据更新
  void OnOrderFlowDataUpdated(const QString &symbol, const OrderFlowData &data);
  
  // 处理订单状态变化
  void OnOrderStatusChanged(const QString &order_id, OrderStatus status);
  
  // 处理订单成交
  void OnOrderFilled(const QString &order_id, const Trade &trade);
  
  // 处理持仓变化
  void OnPositionChanged(const QString &symbol, const Position &position);
  
  // 处理账户信息更新
  void OnAccountUpdated(const Account &account);

 private:
  std::shared_ptr<MarketDataManager> market_data_manager_;
  std::shared_ptr<TradingEngine> trading_engine_;
  
  // 连接信号槽
  void ConnectSignals();
  
  // 断开信号槽
  void DisconnectSignals();
  
  // 初始化默认设置
  void InitializeDefaultSettings();
};

#endif  // MAIN_WINDOW_CONTROLLER_H 