#ifndef OKEX_PROVIDER_H
#define OKEX_PROVIDER_H

#include "market_data/market_data_provider.h"
#include <QNetworkAccessManager>
#include <QWebSocket>
#include <QTimer>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

class OKExProvider : public MarketDataProvider {
  Q_OBJECT

 public:
  explicit OKExProvider(QObject *parent = nullptr);
  ~OKExProvider();

  // 实现基类接口
  QString GetName() const override { return "OKEx"; }
  QString GetType() const override { return "WebSocket"; }
  bool Connect() override;
  void Disconnect() override;
  bool IsConnected() const override;
  bool SubscribeMarketData(const QString &symbol) override;
  bool UnsubscribeMarketData(const QString &symbol) override;
  bool SubscribeOrderFlowData(const QString &symbol) override;
  bool UnsubscribeOrderFlowData(const QString &symbol) override;
  QStringList GetSupportedSymbols() const override;

 private slots:
  void OnWebSocketConnected();
  void OnWebSocketDisconnected();
  void OnWebSocketError(QAbstractSocket::SocketError error);
  void OnWebSocketTextMessageReceived(const QString &message);
  void OnPingTimerTimeout();

 private:
  QWebSocket *websocket_;
  QNetworkAccessManager *network_manager_;
  QTimer *ping_timer_;
  bool is_connected_;
  QStringList subscribed_symbols_;
  
  // WebSocket URL
  const QString kWebSocketUrl = "wss://ws.okx.com:8443/ws/v5/public";
  
  // 处理行情数据消息
  void HandleTickerMessage(const QJsonObject &message);
  
  // 处理订单流数据消息
  void HandleTradeMessage(const QJsonObject &message);
  
  // 发送订阅消息
  void SendSubscribeMessage(const QString &channel, const QString &inst_id);
  
  // 发送取消订阅消息
  void SendUnsubscribeMessage(const QString &channel, const QString &inst_id);
  
  // 发送ping消息
  void SendPing();
  
  // 解析JSON消息
  QJsonObject ParseJsonMessage(const QString &message);
  
  // 验证消息格式
  bool ValidateMessage(const QJsonObject &message);
};

#endif  // OKEX_PROVIDER_H 