#ifndef MARKET_DATA_PROVIDER_H
#define MARKET_DATA_PROVIDER_H

#include <QObject>
#include <QString>
#include <QMap>
#include <functional>

#include "market_data_manager.h"

// 行情数据提供者接口
class MarketDataProvider : public QObject {
  Q_OBJECT

 public:
  explicit MarketDataProvider(QObject *parent = nullptr);
  virtual ~MarketDataProvider() = default;

  // 获取提供者名称
  virtual QString GetName() const = 0;
  
  // 获取提供者类型
  virtual QString GetType() const = 0;
  
  // 连接行情数据源
  virtual bool Connect() = 0;
  
  // 断开行情数据源
  virtual void Disconnect() = 0;
  
  // 检查连接状态
  virtual bool IsConnected() const = 0;
  
  // 订阅行情数据
  virtual bool SubscribeMarketData(const QString &symbol) = 0;
  
  // 取消订阅行情数据
  virtual bool UnsubscribeMarketData(const QString &symbol) = 0;
  
  // 订阅订单流数据
  virtual bool SubscribeOrderFlowData(const QString &symbol) = 0;
  
  // 取消订阅订单流数据
  virtual bool UnsubscribeOrderFlowData(const QString &symbol) = 0;
  
  // 获取支持的交易对列表
  virtual QStringList GetSupportedSymbols() const = 0;
  
  // 设置行情数据更新回调
  void SetMarketDataCallback(
      std::function<void(const QString &, const MarketData &)> callback);
  
  // 设置订单流数据更新回调
  void SetOrderFlowDataCallback(
      std::function<void(const QString &, const OrderFlowData &)> callback);

 signals:
  // 连接状态变化信号
  void ConnectionStatusChanged(bool connected);
  
  // 行情数据更新信号
  void MarketDataUpdated(const QString &symbol, const MarketData &data);
  
  // 订单流数据更新信号
  void OrderFlowDataUpdated(const QString &symbol, const OrderFlowData &data);

 protected:
  // 调用行情数据更新回调
  void NotifyMarketDataUpdated(const QString &symbol, const MarketData &data);
  
  // 调用订单流数据更新回调
  void NotifyOrderFlowDataUpdated(const QString &symbol, const OrderFlowData &data);

 private:
  std::function<void(const QString &, const MarketData &)> market_data_callback_;
  std::function<void(const QString &, const OrderFlowData &)> order_flow_callback_;
};

#endif  // MARKET_DATA_PROVIDER_H 