#ifndef MARKET_DATA_MANAGER_H
#define MARKET_DATA_MANAGER_H

#include <QObject>
#include <QString>
#include <QMap>
#include <memory>
#include <vector>

// 前向声明
class MarketDataProvider;
class MarketDataHandler;

// 行情数据类型定义
struct MarketData {
  QString symbol;           // 交易对符号
  double price;            // 当前价格
  double volume;           // 成交量
  double bid_price;        // 买价
  double ask_price;        // 卖价
  double bid_volume;       // 买量
  double ask_volume;       // 卖量
  qint64 timestamp;        // 时间戳
  QString exchange;        // 交易所
};

// 订单流数据类型
struct OrderFlowData {
  QString symbol;
  double price;
  double volume;
  QString side;            // "buy" 或 "sell"
  QString order_type;      // "market", "limit", "stop"
  qint64 timestamp;
  QString exchange;
};

class MarketDataManager : public QObject {
  Q_OBJECT

 public:
  explicit MarketDataManager(QObject *parent = nullptr);
  ~MarketDataManager();

  // 添加行情数据提供者
  void AddProvider(const QString &name, 
                   std::shared_ptr<MarketDataProvider> provider);
  
  // 移除行情数据提供者
  void RemoveProvider(const QString &name);
  
  // 订阅行情数据
  void SubscribeMarketData(const QString &symbol, const QString &provider_name);
  
  // 取消订阅行情数据
  void UnsubscribeMarketData(const QString &symbol, const QString &provider_name);
  
  // 获取当前行情数据
  MarketData GetMarketData(const QString &symbol) const;
  
  // 获取所有订阅的行情数据
  QMap<QString, MarketData> GetAllMarketData() const;

 signals:
  // 行情数据更新信号
  void MarketDataUpdated(const QString &symbol, const MarketData &data);
  
  // 订单流数据更新信号
  void OrderFlowDataUpdated(const QString &symbol, const OrderFlowData &data);
  
  // 连接状态变化信号
  void ConnectionStatusChanged(const QString &provider_name, bool connected);

 public slots:
  // 连接行情数据提供者
  void ConnectProvider(const QString &provider_name);
  
  // 断开行情数据提供者
  void DisconnectProvider(const QString &provider_name);

 private:
  QMap<QString, std::shared_ptr<MarketDataProvider>> providers_;
  QMap<QString, MarketData> market_data_cache_;
  QMap<QString, std::vector<OrderFlowData>> order_flow_cache_;
  
  // 处理行情数据更新
  void OnMarketDataUpdated(const QString &symbol, const MarketData &data);
  
  // 处理订单流数据更新
  void OnOrderFlowDataUpdated(const QString &symbol, const OrderFlowData &data);
};

#endif  // MARKET_DATA_MANAGER_H 