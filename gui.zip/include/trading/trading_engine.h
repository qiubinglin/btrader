#ifndef TRADING_ENGINE_H
#define TRADING_ENGINE_H

#include <QObject>
#include <QString>
#include <QMap>
#include <QList>
#include <memory>

// 订单类型定义
enum class OrderType {
  kMarket,    // 市价单
  kLimit,     // 限价单
  kStop,      // 止损单
  kStopLimit  // 止损限价单
};

// 订单方向
enum class OrderSide {
  kBuy,
  kSell
};

// 订单状态
enum class OrderStatus {
  kPending,     // 待处理
  kSubmitted,   // 已提交
  kPartiallyFilled,  // 部分成交
  kFilled,     // 完全成交
  kCancelled,  // 已取消
  kRejected    // 被拒绝
};

// 订单结构
struct Order {
  QString order_id;        // 订单ID
  QString symbol;          // 交易对
  OrderType type;          // 订单类型
  OrderSide side;          // 订单方向
  double price;            // 价格
  double quantity;         // 数量
  double filled_quantity;  // 已成交数量
  double remaining_quantity; // 剩余数量
  OrderStatus status;      // 订单状态
  qint64 timestamp;        // 时间戳
  QString exchange;        // 交易所
  QString client_order_id; // 客户端订单ID
  QString message;         // 消息
};

// 成交记录
struct Trade {
  QString trade_id;        // 成交ID
  QString order_id;        // 订单ID
  QString symbol;          // 交易对
  OrderSide side;          // 方向
  double price;            // 成交价格
  double quantity;         // 成交数量
  qint64 timestamp;        // 时间戳
  QString exchange;        // 交易所
};

// 持仓信息
struct Position {
  QString symbol;          // 交易对
  double quantity;         // 持仓数量
  double avg_price;        // 平均价格
  double unrealized_pnl;   // 未实现盈亏
  double realized_pnl;     // 已实现盈亏
  QString exchange;        // 交易所
};

// 账户信息
struct Account {
  QString account_id;      // 账户ID
  double balance;          // 余额
  double equity;           // 权益
  double margin;           // 保证金
  double free_margin;      // 可用保证金
  double margin_level;     // 保证金水平
  QString currency;        // 货币
  QString exchange;        // 交易所
};

class TradingEngine : public QObject {
  Q_OBJECT

 public:
  explicit TradingEngine(QObject *parent = nullptr);
  ~TradingEngine();

  // 下单
  QString PlaceOrder(const QString &symbol, OrderType type, OrderSide side,
                     double quantity, double price = 0.0);
  
  // 取消订单
  bool CancelOrder(const QString &order_id);
  
  // 修改订单
  bool ModifyOrder(const QString &order_id, double new_price, double new_quantity);
  
  // 获取订单信息
  Order GetOrder(const QString &order_id) const;
  
  // 获取所有订单
  QList<Order> GetAllOrders() const;
  
  // 获取活跃订单
  QList<Order> GetActiveOrders() const;
  
  // 获取成交记录
  QList<Trade> GetTrades(const QString &symbol = "") const;
  
  // 获取持仓信息
  Position GetPosition(const QString &symbol) const;
  
  // 获取所有持仓
  QMap<QString, Position> GetAllPositions() const;
  
  // 获取账户信息
  Account GetAccount() const;

 signals:
  // 订单状态变化信号
  void OrderStatusChanged(const QString &order_id, OrderStatus status);
  
  // 订单成交信号
  void OrderFilled(const QString &order_id, const Trade &trade);
  
  // 持仓变化信号
  void PositionChanged(const QString &symbol, const Position &position);
  
  // 账户信息更新信号
  void AccountUpdated(const Account &account);

 public slots:
  // 更新订单状态
  void UpdateOrderStatus(const QString &order_id, OrderStatus status);
  
  // 添加成交记录
  void AddTrade(const Trade &trade);
  
  // 更新持仓
  void UpdatePosition(const QString &symbol, const Position &position);
  
  // 更新账户信息
  void UpdateAccount(const Account &account);

 private:
  QMap<QString, Order> orders_;
  QList<Trade> trades_;
  QMap<QString, Position> positions_;
  Account account_;
  
  // 生成订单ID
  QString GenerateOrderId() const;
  
  // 生成成交ID
  QString GenerateTradeId() const;
  
  // 验证订单参数
  bool ValidateOrder(const QString &symbol, OrderType type, OrderSide side,
                     double quantity, double price) const;
};

#endif  // TRADING_ENGINE_H 