#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QDir>

#include "include/market_data/market_data_manager.h"
#include "include/trading/trading_engine.h"
#include "include/ui/main_window_controller.h"

int main(int argc, char *argv[]) {
  QGuiApplication app(argc, argv);
  
  // 设置应用程序信息
  app.setApplicationName("OrderFlowTrader");
  app.setApplicationVersion("1.0.0");
  app.setOrganizationName("OrderFlowTrader");
  
  // 设置QML样式
  QQuickStyle::setStyle("Material");
  
  // 创建QML引擎
  QQmlApplicationEngine engine;
  
  // 创建核心组件
  auto market_data_manager = std::make_shared<MarketDataManager>();
  auto trading_engine = std::make_shared<TradingEngine>();
  auto main_controller = std::make_shared<MainWindowController>(
      market_data_manager, trading_engine);
  
  // 注册C++对象到QML
  engine.rootContext()->setContextProperty("marketDataManager", 
                                         market_data_manager.get());
  engine.rootContext()->setContextProperty("tradingEngine", 
                                         trading_engine.get());
  engine.rootContext()->setContextProperty("mainController", 
                                         main_controller.get());
  
  // 加载主QML文件
  const QUrl url(QStringLiteral("qrc:/main.qml"));
  QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                   &app, [url](QObject *obj, const QUrl &objUrl) {
    if (!obj && url == objUrl)
      QCoreApplication::exit(-1);
  }, Qt::QueuedConnection);
  
  engine.load(url);
  
  return app.exec();
} 