# OrderFlowTrader 技术文档

## 架构设计

### 整体架构

OrderFlowTrader采用模块化设计，主要分为以下几个层次：

```
┌─────────────────────────────────────┐
│              UI Layer               │
│  (QML Components + Controllers)     │
├─────────────────────────────────────┤
│           Business Layer            │
│  (Trading Engine + Market Data)     │
├─────────────────────────────────────┤
│           Core Layer                │
│  (Analysis + Risk Management)       │
├─────────────────────────────────────┤
│         Network Layer               │
│  (WebSocket + HTTP APIs)           │
└─────────────────────────────────────┘
```

### 设计模式

1. **MVC模式** - 分离UI、业务逻辑和数据
2. **观察者模式** - 使用Qt信号槽机制
3. **工厂模式** - 创建不同的数据提供者
4. **策略模式** - 不同的交易策略实现

## 核心模块详解

### 1. 行情数据模块 (Market Data)

#### 类结构

```cpp
// 抽象基类
class MarketDataProvider : public QObject {
    Q_OBJECT
public:
    virtual QString GetName() const = 0;
    virtual QString GetType() const = 0;
    virtual bool Connect() = 0;
    virtual void Disconnect() = 0;
    virtual bool IsConnected() const = 0;
    virtual bool SubscribeMarketData(const QString &symbol) = 0;
    virtual bool UnsubscribeMarketData(const QString &symbol) = 0;
    // ... 其他接口方法
};

// 具体实现
class BinanceProvider : public MarketDataProvider {
    // Binance特定实现
};

class OKExProvider : public MarketDataProvider {
    // OKEx特定实现
};

// 管理器
class MarketDataManager : public QObject {
    Q_OBJECT
private:
    QMap<QString, std::shared_ptr<MarketDataProvider>> providers_;
    QMap<QString, MarketData> market_data_cache_;
};
```

#### 数据流

```
WebSocket连接 → 数据解析 → 缓存更新 → 信号发送 → UI更新
```

#### 关键特性

- **实时性**: WebSocket连接保证数据实时性
- **可靠性**: 自动重连机制
- **扩展性**: 插件式提供者架构
- **缓存**: 本地数据缓存减少网络请求

### 2. 交易引擎模块 (Trading Engine)

#### 核心数据结构

```cpp
// 订单状态枚举
enum class OrderStatus {
    kPending,      // 待处理
    kSubmitted,    // 已提交
    kPartiallyFilled, // 部分成交
    kFilled,      // 完全成交
    kCancelled,   // 已取消
    kRejected     // 被拒绝
};

// 订单类型
enum class OrderType {
    kMarket,      // 市价单
    kLimit,       // 限价单
    kStop,        // 止损单
    kStopLimit    // 止损限价单
};

// 订单方向
enum class OrderSide {
    kBuy,         // 买入
    kSell         // 卖出
};

// 订单结构
struct Order {
    QString order_id;
    QString symbol;
    OrderType type;
    OrderSide side;
    double quantity;
    double price;
    OrderStatus status;
    qint64 timestamp;
    QString exchange;
};
```

#### 交易引擎功能

1. **订单管理**
   - 创建订单
   - 修改订单
   - 取消订单
   - 查询订单状态

2. **持仓管理**
   - 计算持仓
   - 盈亏计算
   - 保证金管理

3. **风险控制**
   - 仓位限制
   - 止损止盈
   - 风险监控

### 3. UI架构

#### QML组件层次

```
ApplicationWindow
├── RowLayout (主布局)
│   ├── ColumnLayout (左侧面板)
│   │   ├── MarketDataPanel
│   │   └── OrderFlowPanel
│   ├── ColumnLayout (中间面板)
│   │   ├── ChartPanel
│   │   └── OrderBookPanel
│   └── ColumnLayout (右侧面板)
│       ├── TradingPanel
│       ├── OrderPanel
│       ├── PositionPanel
│       └── AccountPanel
└── footer (状态栏)
```

#### 数据绑定

```qml
// C++对象注册到QML
engine.rootContext()->setContextProperty("marketDataManager", 
                                       market_data_manager.get());
engine.rootContext()->setContextProperty("tradingEngine", 
                                       trading_engine.get());
engine.rootContext()->setContextProperty("mainController", 
                                       main_controller.get());
```

#### 信号槽连接

```cpp
// C++信号槽
connect(provider.get(), &MarketDataProvider::MarketDataUpdated,
        this, &MarketDataManager::OnMarketDataUpdated);

// QML信号处理
Connections {
    target: marketDataManager
    function onMarketDataUpdated(symbol, data) {
        // 更新UI
    }
}
```

## 网络通信

### WebSocket实现

#### Binance WebSocket

```cpp
// 连接URL
const QString kWebSocketUrl = "wss://stream.binance.com:9443/ws/";

// 订阅消息格式
{
    "method": "SUBSCRIBE",
    "params": ["btcusdt@ticker"],
    "id": 1
}

// 数据消息格式
{
    "e": "24hrTicker",
    "E": 123456789,
    "s": "BTCUSDT",
    "p": "0.0015",
    "P": "250.00",
    "w": "0.0018",
    "x": "0.0009",
    "c": "0.0025",
    "Q": "1000",
    "b": "0.0024",
    "B": "100",
    "a": "0.0026",
    "A": "100",
    "o": "0.0010",
    "h": "0.0025",
    "l": "0.0010",
    "v": "10000",
    "q": "18",
    "O": 0,
    "C": 86400000,
    "F": 0,
    "L": 18150,
    "n": 18151
}
```

#### OKEx WebSocket

```cpp
// 连接URL
const QString kWebSocketUrl = "wss://ws.okx.com:8443/ws/v5/public";

// 订阅消息格式
{
    "op": "subscribe",
    "args": [{
        "channel": "tickers",
        "instId": "BTC-USDT"
    }]
}
```

### 错误处理

```cpp
// 连接错误处理
void OnWebSocketError(QAbstractSocket::SocketError error) {
    qDebug() << "WebSocket error:" << error;
    // 实现重连逻辑
    QTimer::singleShot(5000, this, &MarketDataProvider::Connect);
}

// 心跳机制
void SendPing() {
    if (websocket_ && websocket_->state() == QAbstractSocket::ConnectedState) {
        websocket_->sendTextMessage("ping");
    }
}
```

## 数据模型

### 行情数据结构

```cpp
struct MarketData {
    QString symbol;           // 交易对符号
    double price;            // 当前价格
    double volume;           // 成交量
    double bid_price;        // 买价
    double ask_price;        // 卖价
    double bid_volume;       // 买量
    double ask_volume;       // 卖量
    qint64 timestamp;        // 时间戳
    QString exchange;        // 交易所
};
```

### 订单流数据结构

```cpp
struct OrderFlowData {
    QString symbol;
    double price;
    double volume;
    QString side;            // "buy" 或 "sell"
    QString order_type;      // "market", "limit", "stop"
    qint64 timestamp;
    QString exchange;
};
```

### 持仓数据结构

```cpp
struct Position {
    QString symbol;
    double quantity;
    double avg_price;
    double unrealized_pnl;
    double realized_pnl;
    QString side;
    qint64 timestamp;
};
```

## 性能优化

### 1. 内存管理

- 使用智能指针管理对象生命周期
- 避免循环引用
- 及时释放不需要的资源

### 2. 网络优化

- 连接池复用
- 数据压缩
- 批量请求

### 3. UI性能

- 虚拟化长列表
- 延迟加载
- 异步数据更新

## 安全考虑

### 1. 数据安全

- 敏感数据加密存储
- API密钥安全管理
- 数据传输加密

### 2. 输入验证

- 参数边界检查
- SQL注入防护
- XSS防护

### 3. 错误处理

- 异常捕获
- 日志记录
- 优雅降级

## 测试策略

### 1. 单元测试

```cpp
// 使用Google Test框架
TEST_F(TradingEngineTest, PlaceOrder_ValidOrder_ReturnsOrderId) {
    // 测试用例
}
```

### 2. 集成测试

- 组件间交互测试
- 端到端测试
- 性能测试

### 3. 模拟测试

- Mock WebSocket连接
- 模拟市场数据
- 测试异常情况

## 部署指南

### 1. 依赖管理

```bash
# 安装Qt6
sudo apt-get install qt6-base-dev qt6-declarative-dev

# 安装构建工具
sudo apt-get install cmake build-essential
```

### 2. 构建配置

```cmake
# CMakeLists.txt 关键配置
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)
```

### 3. 打包部署

```bash
# 使用linuxdeployqt打包
linuxdeployqt OrderFlowTrader -appimage
```

## 扩展指南

### 添加新交易所

1. 继承`MarketDataProvider`
2. 实现WebSocket连接
3. 解析特定数据格式
4. 注册到管理器

### 添加新功能

1. 定义数据模型
2. 实现业务逻辑
3. 创建UI组件
4. 集成到主程序

## 监控和日志

### 日志系统

```cpp
// 使用Qt日志系统
qDebug() << "Market data updated:" << symbol << price;
qWarning() << "Connection failed:" << error;
qCritical() << "Critical error:" << message;
```

### 性能监控

- 内存使用监控
- 网络延迟监控
- UI响应时间监控

## 故障排除

### 常见问题

1. **编译错误**
   - 检查Qt版本兼容性
   - 确认依赖库版本
   - 检查编译器设置

2. **运行时错误**
   - 检查文件路径
   - 确认权限设置
   - 查看错误日志

3. **网络问题**
   - 检查防火墙设置
   - 确认网络连接
   - 验证API端点

### 调试技巧

- 使用Qt Creator调试器
- 启用QML调试
- 添加详细日志
- 使用性能分析工具 