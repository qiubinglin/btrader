import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtQuick.Window 2.15

// 导入自定义组件
import "components"

ApplicationWindow {
    id: mainWindow
    visible: true
    width: 1400
    height: 900
    title: "OrderFlowTrader - Trading Platform"
    
    // 设置默认字体
    FontLoader {
        id: defaultFont
        source: ""
    }
    
    // 初始化应用程序
    Component.onCompleted: {
        // 尝试设置中文字体
        var fontFamily = "Microsoft YaHei"
        if (Qt.fontFamilies().indexOf(fontFamily) === -1) {
            fontFamily = "SimHei"
        }
        if (Qt.fontFamilies().indexOf(fontFamily) === -1) {
            fontFamily = "Arial"
        }
        Qt.application.font.family = fontFamily
        
        if (mainController) {
            mainController.Initialize()
        }
    }
    
    // 设置窗口属性
    minimumWidth: 1200
    minimumHeight: 800
    
    // 主题颜色
    property color primaryColor: "#1976D2"
    property color secondaryColor: "#424242"
    property color backgroundColor: "#FAFAFA"
    property color textColor: "#212121"
    property color borderColor: "#E0E0E0"
    

    
    // 主布局
    RowLayout {
        anchors.fill: parent
        spacing: 0
        
        // 左侧面板 - 行情数据和订单流
        ColumnLayout {
            Layout.fillHeight: true
            Layout.preferredWidth: 400
            spacing: 8
            
            // 行情数据面板
            MarketDataPanel {
                Layout.fillWidth: true
                Layout.preferredHeight: 300
            }
            
            // 订单流面板
            OrderFlowPanel {
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
        }
        
        // 中间面板 - 图表和订单簿
        ColumnLayout {
            Layout.fillHeight: true
            Layout.fillWidth: true
            spacing: 8
            
            // 图表面板
            ChartPanel {
                Layout.fillWidth: true
                Layout.preferredHeight: 400
            }
            
            // 订单簿面板
            OrderBookPanel {
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
        }
        
        // 右侧面板 - 交易和账户信息
        ColumnLayout {
            Layout.fillHeight: true
            Layout.preferredWidth: 350
            spacing: 8
            
            // 交易面板
            TradingPanel {
                Layout.fillWidth: true
                Layout.preferredHeight: 250
            }
            
            // 订单面板
            OrderPanel {
                Layout.fillWidth: true
                Layout.preferredHeight: 200
            }
            
            // 持仓面板
            PositionPanel {
                Layout.fillWidth: true
                Layout.preferredHeight: 150
            }
            
            // 账户面板
            AccountPanel {
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
        }
    }
    
    // 状态栏
    footer: Rectangle {
        height: 30
        color: secondaryColor
        
        RowLayout {
            anchors.fill: parent
            anchors.margins: 5
            spacing: 10
            
            Text {
                text: "Status: Connected"
                color: "white"
                font.pixelSize: 12
            }
            
            Item { Layout.fillWidth: true }
            
            Text {
                text: "Account: SIMULATED_ACCOUNT"
                color: "white"
                font.pixelSize: 12
            }
            
            Text {
                text: "Balance: 100000.00 USDT"
                color: "white"
                font.pixelSize: 12
            }
        }
    }
    
    // 菜单栏
    menuBar: MenuBar {
        Menu {
            title: "File"
            MenuItem {
                text: "Settings"
                onTriggered: {
                    // Open settings dialog
                }
            }
            MenuItem {
                text: "Exit"
                onTriggered: Qt.quit()
            }
        }
        
        Menu {
            title: "Market Data"
            MenuItem {
                text: "Connect Binance"
                onTriggered: {
                    if (mainController) {
                        mainController.ConnectMarketData("Binance")
                    }
                }
            }
            MenuItem {
                text: "Connect OKEx"
                onTriggered: {
                    if (mainController) {
                        mainController.ConnectMarketData("OKEx")
                    }
                }
            }
            MenuItem {
                text: "Disconnect All"
                onTriggered: {
                    if (mainController) {
                        mainController.DisconnectMarketData("Binance")
                        mainController.DisconnectMarketData("OKEx")
                    }
                }
            }
        }
        
        Menu {
            title: "Help"
            MenuItem {
                text: "About"
                onTriggered: {
                    // Show about dialog
                }
            }
        }
    }
} 