import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: marketDataPanel
    color: "#FAFAFA"
    border.color: "#E0E0E0"
    border.width: 1
    
    // 行情数据模型
    property var marketData: ({})
    property string selectedSymbol: "BTCUSDT"
    
    // 更新行情数据
    function updateMarketData(symbol, data) {
        marketData[symbol] = data
        if (symbol === selectedSymbol) {
            priceText.text = data.price ? data.price.toFixed(2) : "0.00"
            volumeText.text = data.volume ? data.volume.toFixed(2) : "0.00"
            bidText.text = data.bid_price ? data.bid_price.toFixed(2) : "0.00"
            askText.text = data.ask_price ? data.ask_price.toFixed(2) : "0.00"
        }
    }
    
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10
        
        // 标题
        Rectangle {
            Layout.fillWidth: true
            height: 30
            color: "#1976D2"
            
            Text {
                anchors.centerIn: parent
                text: "Market Data"
                color: "white"
                font.pixelSize: 14
                font.bold: true
            }
        }
        
        // 交易对选择
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            
            Text {
                text: "Symbol:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            ComboBox {
                id: symbolComboBox
                Layout.fillWidth: true
                model: ["BTCUSDT", "ETHUSDT", "BNBUSDT", "ADAUSDT", "DOTUSDT"]
                currentIndex: 0
                
                onCurrentTextChanged: {
                    selectedSymbol = currentText
                    if (mainController) {
                        mainController.SubscribeSymbol(currentText, "Binance")
                    }
                }
            }
        }
        
        // 价格信息
        GridLayout {
            Layout.fillWidth: true
            columns: 2
            rowSpacing: 8
            columnSpacing: 10
            
            Text {
                text: "Current Price:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                id: priceText
                text: "0.00"
                color: "#1976D2"
                font.pixelSize: 16
                font.bold: true
            }
            
            Text {
                text: "24h Volume:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                id: volumeText
                text: "0.00"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                text: "Bid:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                id: bidText
                text: "0.00"
                color: "#4CAF50"
                font.pixelSize: 12
            }
            
            Text {
                text: "Ask:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                id: askText
                text: "0.00"
                color: "#F44336"
                font.pixelSize: 12
            }
        }
        
        // 连接状态
        Rectangle {
            Layout.fillWidth: true
            height: 25
            color: "#E8F5E8"
            border.color: "#4CAF50"
            border.width: 1
            radius: 4
            
            Text {
                anchors.centerIn: parent
                text: "Binance: Connected"
                color: "#4CAF50"
                font.pixelSize: 11
            }
        }
        
        // 行情数据列表
        ListView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            
            model: ListModel {
                id: marketDataModel
            }
            
            delegate: Rectangle {
                width: parent.width
                height: 30
                color: index % 2 === 0 ? "#F5F5F5" : "white"
                
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    spacing: 10
                    
                    Text {
                        text: model.symbol
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.preferredWidth: 80
                    }
                    
                    Text {
                        text: model.price
                        color: "#1976D2"
                        font.pixelSize: 11
                        font.bold: true
                        Layout.preferredWidth: 70
                    }
                    
                    Text {
                        text: model.change
                        color: model.changeColor
                        font.pixelSize: 11
                        Layout.preferredWidth: 60
                    }
                    
                    Text {
                        text: model.volume
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.fillWidth: true
                    }
                }
            }
        }
    }
    
    // 连接信号
    Connections {
        target: marketDataManager
        
        function onMarketDataUpdated(symbol, data) {
            updateMarketData(symbol, data)
            
            // 更新列表模型
            let found = false
            for (let i = 0; i < marketDataModel.count; i++) {
                if (marketDataModel.get(i).symbol === symbol) {
                    marketDataModel.set(i, {
                        symbol: symbol,
                        price: data.price ? data.price.toFixed(2) : "0.00",
                        change: "+0.00%",
                        changeColor: "#4CAF50",
                        volume: data.volume ? data.volume.toFixed(2) : "0.00"
                    })
                    found = true
                    break
                }
            }
            
            if (!found) {
                marketDataModel.append({
                    symbol: symbol,
                    price: data.price ? data.price.toFixed(2) : "0.00",
                    change: "+0.00%",
                    changeColor: "#4CAF50",
                    volume: data.volume ? data.volume.toFixed(2) : "0.00"
                })
            }
        }
    }
} 