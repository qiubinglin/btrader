import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: orderFlowPanel
    color: "#FAFAFA"
    border.color: "#E0E0E0"
    border.width: 1
    
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10
        
        // 标题
        Rectangle {
            Layout.fillWidth: true
            height: 30
            color: "#1976D2"
            
            Text {
                anchors.centerIn: parent
                text: "Order Flow"
                color: "white"
                font.pixelSize: 14
                font.bold: true
            }
        }
        
        // 订单流列表
        ListView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            
            model: ListModel {
                id: orderFlowModel
            }
            
            delegate: Rectangle {
                width: parent.width
                height: 25
                color: model.side === "buy" ? "#E8F5E8" : "#FFEBEE"
                
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    spacing: 8
                    
                    Text {
                        text: model.time
                        color: "#212121"
                        font.pixelSize: 10
                        Layout.preferredWidth: 60
                    }
                    
                    Text {
                        text: model.price
                        color: model.side === "buy" ? "#4CAF50" : "#F44336"
                        font.pixelSize: 11
                        font.bold: true
                        Layout.preferredWidth: 70
                    }
                    
                    Text {
                        text: model.quantity
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.preferredWidth: 60
                    }
                    
                    Text {
                        text: model.side === "buy" ? "买入" : "卖出"
                        color: model.side === "buy" ? "#4CAF50" : "#F44336"
                        font.pixelSize: 11
                        Layout.preferredWidth: 40
                    }
                    
                    Text {
                        text: model.exchange
                        color: "#212121"
                        font.pixelSize: 10
                        Layout.fillWidth: true
                    }
                }
            }
        }
    }
    
    // 连接信号
    Connections {
        target: marketDataManager
        
        function onOrderFlowDataUpdated(symbol, data) {
            // 添加新的订单流数据到列表顶部
            orderFlowModel.insert(0, {
                time: new Date(data.timestamp).toLocaleTimeString(),
                price: data.price.toFixed(2),
                quantity: data.volume.toFixed(4),
                side: data.side,
                exchange: data.exchange
            })
            
            // 保持最多100条记录
            if (orderFlowModel.count > 100) {
                orderFlowModel.remove(orderFlowModel.count - 1)
            }
        }
    }
} 