import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: orderPanel
    color: "#FAFAFA"
    border.color: "#E0E0E0"
    border.width: 1
    
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10
        
        // 标题
        Rectangle {
            Layout.fillWidth: true
            height: 30
            color: "#1976D2"
            
            Text {
                anchors.centerIn: parent
                text: "Orders"
                color: "white"
                font.pixelSize: 14
                font.bold: true
            }
        }
        
        // 订单列表
        ListView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            
            model: ListModel {
                id: orderModel
            }
            
            delegate: Rectangle {
                width: parent.width
                height: 40
                color: index % 2 === 0 ? "#F5F5F5" : "white"
                border.color: "#E0E0E0"
                border.width: 1
                
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    spacing: 8
                    
                    Text {
                        text: model.symbol
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.preferredWidth: 60
                    }
                    
                    Text {
                        text: model.side === 0 ? "买入" : "卖出"
                        color: model.side === 0 ? "#4CAF50" : "#F44336"
                        font.pixelSize: 11
                        font.bold: true
                        Layout.preferredWidth: 40
                    }
                    
                    Text {
                        text: model.quantity
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.preferredWidth: 50
                    }
                    
                    Text {
                        text: model.price
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.preferredWidth: 60
                    }
                    
                    Text {
                        text: getStatusText(model.status)
                        color: getStatusColor(model.status)
                        font.pixelSize: 11
                        Layout.preferredWidth: 60
                    }
                    
                    Button {
                        text: "取消"
                        enabled: model.status === 1 || model.status === 2
                        height: 20
                        
                        background: Rectangle {
                            color: parent.enabled ? "#F44336" : "#E0E0E0"
                            radius: 2
                        }
                        
                        contentItem: Text {
                            text: parent.text
                            color: "white"
                            font.pixelSize: 10
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                        
                        onClicked: {
                            if (mainController) {
                                mainController.cancelOrder(model.orderId)
                            }
                        }
                    }
                }
            }
        }
    }
    
    // 获取状态文本
    function getStatusText(status) {
        switch (status) {
            case 0: return "待处理"
            case 1: return "已提交"
            case 2: return "部分成交"
            case 3: return "完全成交"
            case 4: return "已取消"
            case 5: return "被拒绝"
            default: return "未知"
        }
    }
    
    // 获取状态颜色
    function getStatusColor(status) {
        switch (status) {
            case 0: return "#FF9800"
            case 1: return "#2196F3"
            case 2: return "#9C27B0"
            case 3: return "#4CAF50"
            case 4: return "#F44336"
            case 5: return "#F44336"
            default: return "#757575"
        }
    }
    
    // 添加订单
    function addOrder(order) {
        orderModel.append({
            orderId: order.order_id,
            symbol: order.symbol,
            side: order.side,
            quantity: order.quantity.toFixed(4),
            price: order.price.toFixed(2),
            status: order.status
        })
    }
    
    // 更新订单状态
    function updateOrderStatus(orderId, status) {
        for (let i = 0; i < orderModel.count; i++) {
            if (orderModel.get(i).orderId === orderId) {
                orderModel.set(i, {
                    orderId: orderModel.get(i).orderId,
                    symbol: orderModel.get(i).symbol,
                    side: orderModel.get(i).side,
                    quantity: orderModel.get(i).quantity,
                    price: orderModel.get(i).price,
                    status: status
                })
                break
            }
        }
    }
    
    // 连接信号
    Connections {
        target: tradingEngine
        
        function onOrderStatusChanged(orderId, status) {
            updateOrderStatus(orderId, status)
        }
    }
} 