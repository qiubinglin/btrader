import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: accountPanel
    color: "#FAFAFA"
    border.color: "#E0E0E0"
    border.width: 1
    
    // 账户信息属性
    property string accountId: "SIMULATED_ACCOUNT"
    property double balance: 100000.0
    property double equity: 100000.0
    property double margin: 0.0
    property double freeMargin: 100000.0
    property double marginLevel: 0.0
    property string currency: "USDT"
    
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10
        
        // 标题
        Rectangle {
            Layout.fillWidth: true
            height: 30
            color: "#1976D2"
            
            Text {
                anchors.centerIn: parent
                text: "Account Info"
                color: "white"
                font.pixelSize: 14
                font.bold: true
            }
        }
        
        // 账户信息
        GridLayout {
            Layout.fillWidth: true
            columns: 2
            rowSpacing: 8
            columnSpacing: 10
            
            Text {
                text: "Account ID:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                text: accountId
                color: "#212121"
                font.pixelSize: 12
                font.bold: true
            }
            
            Text {
                text: "Balance:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                text: balance.toFixed(2) + " " + currency
                color: "#1976D2"
                font.pixelSize: 12
                font.bold: true
            }
            
            Text {
                text: "Equity:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                text: equity.toFixed(2) + " " + currency
                color: "#1976D2"
                font.pixelSize: 12
                font.bold: true
            }
            
            Text {
                text: "Margin:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                text: margin.toFixed(2) + " " + currency
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                text: "Free Margin:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                text: freeMargin.toFixed(2) + " " + currency
                color: "#4CAF50"
                font.pixelSize: 12
                font.bold: true
            }
            
            Text {
                text: "Margin Level:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            Text {
                text: marginLevel.toFixed(2) + "%"
                color: marginLevel > 100 ? "#4CAF50" : "#F44336"
                font.pixelSize: 12
                font.bold: true
            }
        }
        
        // 账户状态
        Rectangle {
            Layout.fillWidth: true
            height: 25
            color: "#E8F5E8"
            border.color: "#4CAF50"
            border.width: 1
            radius: 4
            
            Text {
                anchors.centerIn: parent
                text: "账户状态: 正常"
                color: "#4CAF50"
                font.pixelSize: 11
            }
        }
    }
    
    // 连接信号
    Connections {
        target: tradingEngine
        
        function onAccountUpdated(account) {
            accountId = account.account_id
            balance = account.balance
            equity = account.equity
            margin = account.margin
            freeMargin = account.free_margin
            marginLevel = account.margin_level
            currency = account.currency
        }
    }
} 