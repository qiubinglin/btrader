import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: positionPanel
    color: "#FAFAFA"
    border.color: "#E0E0E0"
    border.width: 1
    
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10
        
        // 标题
        Rectangle {
            Layout.fillWidth: true
            height: 30
            color: "#1976D2"
            
            Text {
                anchors.centerIn: parent
                text: "Positions"
                color: "white"
                font.pixelSize: 14
                font.bold: true
            }
        }
        
        // 持仓列表
        ListView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            
            model: ListModel {
                id: positionModel
            }
            
            delegate: Rectangle {
                width: parent.width
                height: 35
                color: index % 2 === 0 ? "#F5F5F5" : "white"
                border.color: "#E0E0E0"
                border.width: 1
                
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    spacing: 8
                    
                    Text {
                        text: model.symbol
                        color: "#212121"
                        font.pixelSize: 11
                        font.bold: true
                        Layout.preferredWidth: 60
                    }
                    
                    Text {
                        text: model.quantity
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.preferredWidth: 50
                    }
                    
                    Text {
                        text: model.avgPrice
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.preferredWidth: 60
                    }
                    
                    Text {
                        text: model.unrealizedPnl
                        color: model.unrealizedPnlColor
                        font.pixelSize: 11
                        font.bold: true
                        Layout.preferredWidth: 70
                    }
                }
            }
        }
    }
    
    // 更新持仓
    function updatePosition(symbol, position) {
        let found = false
        for (let i = 0; i < positionModel.count; i++) {
            if (positionModel.get(i).symbol === symbol) {
                positionModel.set(i, {
                    symbol: symbol,
                    quantity: position.quantity.toFixed(4),
                    avgPrice: position.avg_price.toFixed(2),
                    unrealizedPnl: position.unrealized_pnl.toFixed(2),
                    unrealizedPnlColor: position.unrealized_pnl >= 0 ? "#4CAF50" : "#F44336"
                })
                found = true
                break
            }
        }
        
        if (!found && position.quantity !== 0) {
            positionModel.append({
                symbol: symbol,
                quantity: position.quantity.toFixed(4),
                avgPrice: position.avg_price.toFixed(2),
                unrealizedPnl: position.unrealized_pnl.toFixed(2),
                unrealizedPnlColor: position.unrealized_pnl >= 0 ? "#4CAF50" : "#F44336"
            })
        }
    }
    
    // 连接信号
    Connections {
        target: tradingEngine
        
        function onPositionChanged(symbol, position) {
            updatePosition(symbol, position)
        }
    }
} 