import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: tradingPanel
    color: "#FAFAFA"
    border.color: "#E0E0E0"
    border.width: 1
    
    // 交易参数
    property string selectedSymbol: "BTCUSDT"
    property int orderType: 0  // 0: 市价单, 1: 限价单
    property int orderSide: 0  // 0: 买入, 1: 卖出
    property double quantity: 0.0
    property double price: 0.0
    
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10
        
        // 标题
        Rectangle {
            Layout.fillWidth: true
            height: 30
            color: "#1976D2"
            
            Text {
                anchors.centerIn: parent
                text: "Trading Panel"
                color: "white"
                font.pixelSize: 14
                font.bold: true
            }
        }
        
        // 交易对选择
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            
            Text {
                text: "Symbol:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            ComboBox {
                id: symbolComboBox
                Layout.fillWidth: true
                model: ["BTCUSDT", "ETHUSDT", "BNBUSDT", "ADAUSDT", "DOTUSDT"]
                currentIndex: 0
                
                onCurrentTextChanged: {
                    selectedSymbol = currentText
                }
            }
        }
        
        // 订单类型
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            
            Text {
                text: "Order Type:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            ComboBox {
                id: orderTypeComboBox
                Layout.fillWidth: true
                model: ["Market", "Limit"]
                currentIndex: 0
                
                onCurrentIndexChanged: {
                    orderType = currentIndex
                    priceTextField.enabled = currentIndex === 1
                }
            }
        }
        
        // 价格输入（限价单）
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            
            Text {
                text: "Price:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            TextField {
                id: priceTextField
                Layout.fillWidth: true
                placeholderText: "Enter price"
                enabled: false
                text: "0.00"
                
                onTextChanged: {
                    price = parseFloat(text) || 0.0
                }
            }
        }
        
        // 数量输入
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            
            Text {
                text: "Quantity:"
                color: "#212121"
                font.pixelSize: 12
            }
            
            TextField {
                id: quantityTextField
                Layout.fillWidth: true
                placeholderText: "Enter quantity"
                text: "0.00"
                
                onTextChanged: {
                    quantity = parseFloat(text) || 0.0
                }
            }
        }
        
        // 买卖按钮
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            
            Button {
                Layout.fillWidth: true
                height: 40
                text: "Buy"
                
                background: Rectangle {
                    color: parent.pressed ? "#388E3C" : "#4CAF50"
                    radius: 4
                }
                
                contentItem: Text {
                    text: parent.text
                    color: "white"
                    font.pixelSize: 14
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                
                onClicked: {
                    orderSide = 0
                    placeOrder()
                }
            }
            
            Button {
                Layout.fillWidth: true
                height: 40
                text: "Sell"
                
                background: Rectangle {
                    color: parent.pressed ? "#D32F2F" : "#F44336"
                    radius: 4
                }
                
                contentItem: Text {
                    text: parent.text
                    color: "white"
                    font.pixelSize: 14
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                
                onClicked: {
                    orderSide = 1
                    placeOrder()
                }
            }
        }
        
        // 快速数量按钮
        RowLayout {
            Layout.fillWidth: true
            spacing: 5
            
            Button {
                Layout.fillWidth: true
                height: 25
                text: "25%"
                
                background: Rectangle {
                    color: parent.pressed ? "#E0E0E0" : "#F5F5F5"
                    border.color: "#E0E0E0"
                    border.width: 1
                    radius: 4
                }
                
                onClicked: {
                    quantityTextField.text = "0.25"
                }
            }
            
            Button {
                Layout.fillWidth: true
                height: 25
                text: "50%"
                
                background: Rectangle {
                    color: parent.pressed ? "#E0E0E0" : "#F5F5F5"
                    border.color: "#E0E0E0"
                    border.width: 1
                    radius: 4
                }
                
                onClicked: {
                    quantityTextField.text = "0.50"
                }
            }
            
            Button {
                Layout.fillWidth: true
                height: 25
                text: "75%"
                
                background: Rectangle {
                    color: parent.pressed ? "#E0E0E0" : "#F5F5F5"
                    border.color: "#E0E0E0"
                    border.width: 1
                    radius: 4
                }
                
                onClicked: {
                    quantityTextField.text = "0.75"
                }
            }
            
            Button {
                Layout.fillWidth: true
                height: 25
                text: "100%"
                
                background: Rectangle {
                    color: parent.pressed ? "#E0E0E0" : "#F5F5F5"
                    border.color: "#E0E0E0"
                    border.width: 1
                    radius: 4
                }
                
                onClicked: {
                    quantityTextField.text = "1.00"
                }
            }
        }
    }
    
    // 下单函数
    function placeOrder() {
        if (quantity <= 0) {
            console.log("数量必须大于0")
            return
        }
        
        if (orderType === 1 && price <= 0) {
            console.log("限价单价格必须大于0")
            return
        }
        
        if (mainController) {
            mainController.placeOrder(selectedSymbol, orderType, orderSide, quantity, price)
            console.log("下单: " + selectedSymbol + ", 类型: " + orderType + ", 方向: " + orderSide + ", 数量: " + quantity + ", 价格: " + price)
        }
    }
} 