import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: chartPanel
    color: "#FAFAFA"
    border.color: "#E0E0E0"
    border.width: 1
    
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10
        
        // 标题栏
        RowLayout {
            Layout.fillWidth: true
            height: 30
            
            Rectangle {
                Layout.fillWidth: true
                height: 30
                color: "#1976D2"
                
                Text {
                    anchors.centerIn: parent
                    text: "Price Chart"
                    color: "white"
                    font.pixelSize: 14
                    font.bold: true
                }
            }
            
            // 时间周期选择
            ComboBox {
                height: 25
                model: ["1m", "5m", "15m", "1h", "4h", "1d"]
                currentIndex: 3
            }
        }
        
        // 图表区域
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            color: "#FFFFFF"
            border.color: "#E0E0E0"
            border.width: 1
            
            // 简单的价格显示
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 20
                spacing: 10
                
                Text {
                    text: "BTCUSDT Price Chart"
                    color: "#212121"
                    font.pixelSize: 16
                    font.bold: true
                }
                
                Text {
                    id: priceDisplay
                    text: "Current Price: $0.00"
                    color: "#1976D2"
                    font.pixelSize: 24
                    font.bold: true
                }
                
                Text {
                    id: changeDisplay
                    text: "24h Change: +0.00%"
                    color: "#4CAF50"
                    font.pixelSize: 14
                }
                
                // 简单的价格图表（模拟）
                Rectangle {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    color: "#F5F5F5"
                    border.color: "#E0E0E0"
                    border.width: 1
                    
                    Canvas {
                        id: priceChart
                        anchors.fill: parent
                        anchors.margins: 10
                        
                        onPaint: {
                            var ctx = getContext("2d")
                            ctx.strokeStyle = "#1976D2"
                            ctx.lineWidth = 2
                            ctx.beginPath()
                            
                            // 绘制简单的价格线
                            var width = priceChart.width
                            var height = priceChart.height
                            var points = chartData.length
                            
                            for (var i = 0; i < points; i++) {
                                var x = (i / (points - 1)) * width
                                var y = height - (chartData[i] / maxPrice) * height
                                
                                if (i === 0) {
                                    ctx.moveTo(x, y)
                                } else {
                                    ctx.lineTo(x, y)
                                }
                            }
                            
                            ctx.stroke()
                        }
                    }
                }
            }
        }
    }
    
    // 属性
    property var chartData: []
    property double maxPrice: 0
    
    // 更新图表数据
    function updateChartData(price) {
        chartData.push(price)
        if (chartData.length > 100) {
            chartData.shift()
        }
        
        maxPrice = Math.max(...chartData)
        priceDisplay.text = "当前价格: $" + price.toFixed(2)
        
        if (chartData.length > 1) {
            var change = ((price - chartData[0]) / chartData[0]) * 100
            changeDisplay.text = "24h变化: " + (change >= 0 ? "+" : "") + change.toFixed(2) + "%"
            changeDisplay.color = change >= 0 ? "#4CAF50" : "#F44336"
        }
        
        priceChart.requestPaint()
    }
    
    // 连接信号
    Connections {
        target: marketDataManager
        
        function onMarketDataUpdated(symbol, data) {
            if (symbol === "BTCUSDT") {
                updateChartData(data.price)
            }
        }
    }
} 