import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: orderBookPanel
    color: "#FAFAFA"
    border.color: "#E0E0E0"
    border.width: 1
    
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10
        
        // 标题
        Rectangle {
            Layout.fillWidth: true
            height: 30
            color: "#1976D2"
            
            Text {
                anchors.centerIn: parent
                text: "Order Book"
                color: "white"
                font.pixelSize: 14
                font.bold: true
            }
        }
        
        // 表头
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            
            Text {
                text: "Price"
                color: "#212121"
                font.pixelSize: 12
                font.bold: true
                Layout.preferredWidth: 80
            }
            
            Text {
                text: "Quantity"
                color: "#212121"
                font.pixelSize: 12
                font.bold: true
                Layout.preferredWidth: 80
            }
            
            Text {
                text: "Total"
                color: "#212121"
                font.pixelSize: 12
                font.bold: true
                Layout.fillWidth: true
            }
        }
        
        // 卖单列表
        ListView {
            Layout.fillWidth: true
            Layout.preferredHeight: 150
            clip: true
            
            model: ListModel {
                id: askModel
            }
            
            delegate: Rectangle {
                width: parent.width
                height: 20
                color: "#FFEBEE"
                
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 3
                    spacing: 10
                    
                    Text {
                        text: model.price
                        color: "#F44336"
                        font.pixelSize: 11
                        Layout.preferredWidth: 80
                    }
                    
                    Text {
                        text: model.quantity
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.preferredWidth: 80
                    }
                    
                    Text {
                        text: model.total
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.fillWidth: true
                    }
                }
            }
        }
        
        // 当前价格
        Rectangle {
            Layout.fillWidth: true
            height: 30
            color: "#E3F2FD"
            border.color: "#2196F3"
            border.width: 1
            
            Text {
                anchors.centerIn: parent
                text: "Current Price: " + (currentPrice || "0.00")
                color: "#1976D2"
                font.pixelSize: 14
                font.bold: true
            }
        }
        
        // 买单列表
        ListView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            
            model: ListModel {
                id: bidModel
            }
            
            delegate: Rectangle {
                width: parent.width
                height: 20
                color: "#E8F5E8"
                
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 3
                    spacing: 10
                    
                    Text {
                        text: model.price
                        color: "#4CAF50"
                        font.pixelSize: 11
                        Layout.preferredWidth: 80
                    }
                    
                    Text {
                        text: model.quantity
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.preferredWidth: 80
                    }
                    
                    Text {
                        text: model.total
                        color: "#212121"
                        font.pixelSize: 11
                        Layout.fillWidth: true
                    }
                }
            }
        }
    }
    
    // 属性
    property string currentPrice: "0.00"
    
    // 更新订单簿数据
    function updateOrderBook(asks, bids, price) {
        currentPrice = price.toFixed(2)
        
        // 清空现有数据
        askModel.clear()
        bidModel.clear()
        
        // 添加卖单数据
        for (let i = 0; i < Math.min(asks.length, 10); i++) {
            askModel.append({
                price: asks[i].price.toFixed(2),
                quantity: asks[i].quantity.toFixed(4),
                total: asks[i].total.toFixed(4)
            })
        }
        
        // 添加买单数据
        for (let i = 0; i < Math.min(bids.length, 10); i++) {
            bidModel.append({
                price: bids[i].price.toFixed(2),
                quantity: bids[i].quantity.toFixed(4),
                total: bids[i].total.toFixed(4)
            })
        }
    }
    
    // 连接信号
    Connections {
        target: marketDataManager
        
        function onMarketDataUpdated(symbol, data) {
            // 模拟订单簿数据
            let asks = []
            let bids = []
            let basePrice = data.price || 50000
            
            // 生成卖单数据
            for (let i = 1; i <= 10; i++) {
                asks.push({
                    price: basePrice + i * 10,
                    quantity: Math.random() * 2 + 0.1,
                    total: 0
                })
            }
            
            // 生成买单数据
            for (let i = 1; i <= 10; i++) {
                bids.push({
                    price: basePrice - i * 10,
                    quantity: Math.random() * 2 + 0.1,
                    total: 0
                })
            }
            
            // 计算累计数量
            let askTotal = 0
            for (let ask of asks) {
                askTotal += ask.quantity
                ask.total = askTotal
            }
            
            let bidTotal = 0
            for (let bid of bids) {
                bidTotal += bid.quantity
                bid.total = bidTotal
            }
            
            updateOrderBook(asks, bids, basePrice)
        }
    }
} 